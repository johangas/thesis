#define BYTE_ORDER 1234
#define HAVE_ASSERT_H 1
typedef int ssize_t;
